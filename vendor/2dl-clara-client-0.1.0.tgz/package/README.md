# @2dl/clara-client

Attaches a host Electron app to **Clara**, the separately installed assistant chat window. Clara docks beside
the app (app 75 %, Clara 25 %), drives the app's own MCP server, and works through the customer's own
already-signed-in `claude` or `codex`. Windows only. The package has no dependencies; `electron` is a peer.

## Install (link)

```bat
cd D:\Git\maestro\packages\clara-client
npm run build
yarn link

cd <your app>
yarn link "@2dl/clara-client"
```

Rebuild (`npm run build`) after changing the client; the app imports `dist/`.

## Use

```ts
import { AttachClara } from "@2dl/clara-client";

const clara = await AttachClara(mainWindow, {
    appId: "ebook",
    appName: "ebook",
    folder: "D:\\Books\\MyBook",
    mcp: { type: "http", url: "http://127.0.0.1:7311/mcp" },
    access: "app-only",
    tools: { export_pdf: { risky: true, label: "Export {fileName}" } },
    instructions: "You help authors lay out and export books.",
});
if ("not-installed" === clara.status) { /* tell the user, or run the installer snippet */ }
if ("failed" === clara.status) console.error(clara.error);
clara.on("closed", () => { /* Clara went away; the window already has its old bounds back */ });
clara.on("error", (message) => { /* a problem reported while attached */ });
clara.Detach();
```

`AttachClara` never rejects. `status` is `"attached"`, `"not-installed"` (no Clara.exe found: the installer's
`%APPDATA%\Clara\install-path.txt`, then its registry key, then `%LOCALAPPDATA%\Programs\clara`) or
`"failed"` (`error` says why). A Clara it launches may take a while on its first start; it is waited for
(up to 30 s) while it runs. Start your MCP server **before** attaching if you can; if it is unreachable,
Clara still opens and shows "Can't reach <app>'s tools" with a Retry button.

If `AttachClara` returns `"failed"` (for example while Clara is updating itself), the app may call it again
after a few seconds.

### Options

| Option | Meaning |
|---|---|
| `appId` | Stable id. Keys chat history and the remembered split ratio. Also names the MCP server: `clara_` + the id lowercased with every non `[a-z0-9]` character turned into `_` (`my-app` becomes `clara_my_app`). |
| `appName` | Shown to the customer and used in Clara's persona. |
| `folder` | Working folder, fixed for this attach. To change it: `Detach()`, then `AttachClara` again. |
| `mcp` | The app's MCP server: `{ type: "http", url, headers? }` or `{ type: "stdio", command, args?, env? }`. |
| `access` | What Clara may do beyond the app's tools (below). |
| `tools` | Per-tool overrides keyed by the tool's short name: `{ risky?, label? }`. |
| `instructions` | Extra text appended to Clara's persona. |

One Clara process runs per Windows user, with one window per attached app. Only an app launches Clara. Clara
quits a few seconds after its last window closes, so `Detach()` followed by `AttachClara` (a folder change)
finds it still running. Clara's close button detaches and gives the app its pre-attach bounds back.

The first chat in a folder Claude has not worked in before shows a card asking the customer's OK to work
there (Claude's own folder-trust question, asked once per folder). Cancel ends that chat.

### Access levels

The app's own MCP tools are always available. `access` controls everything else:

| Level | Allows |
|---|---|
| `"app-only"` | Only the app's tools. Reading or running anything else is refused. |
| `"read-files"` | Also `Read`, `Glob`, `Grep` inside `folder` only. Anything outside, and all writes/commands, are refused. Paths are checked as written: a junction or link inside `folder` that points elsewhere is not detected. |
| `"full"` | Everything else the CLI can do. Reads run silently; every write, command, web access and other MCP server's tool shows the approval card first, unless the customer chose "Always allow" for it in this chat. |

### Safe and risky tools

A tool runs without asking unless it is **risky**. Risky tools show an approval card first.

- By default a tool is risky when its MCP annotations say `destructiveHint: true`. `readOnlyHint` and
  unannotated tools run silently.
- `tools: { name: { risky: true | false } }` overrides the annotation either way.
- If the app's tool list could not be loaded, every app tool asks for approval until it loads (except tools
  you marked `risky: false`).

### Labels and approval cards

The step line (what the customer sees while Clara works) is, in order: your `label` template, else the MCP
tool's `title`, else the tool name made readable (`export_pdf` becomes "Export pdf"). The approval card title
is the same text with a "?", and the card also shows the MCP `description` as a subtitle (card only).
Arguments appear only when your `label` uses `{argName}`.

```ts
tools: { export_pdf: { risky: true, label: "Export {fileName}" } }   // "Export my-book.pdf?"
```

Template rules:

- `{argName}` matches word characters and is filled from the call's arguments.
- Each value is cut at 60 characters with "…".
- A missing argument becomes an empty string on the step line.
- On the approval card, if any placeholder's argument is missing, Clara uses the MCP title or the readable
  name instead of the template.

Approval cards offer Allow, Always allow (for the rest of the chat), Deny, or a text box to tell Clara what to
do instead.

Attachments are images only in v1, on both backends.

## Backend limits (Codex)

Clara can run on Claude or Codex. Codex differs:

- Codex decides on its own which commands are safe. Safe shell commands such as `ls` or `cat` run without
  asking.
- The read-only sandbox can read files outside `folder`, so `app-only` and `read-files` are not a hard
  boundary on Codex the way they are on Claude.
- Codex decides whether an MCP call raises an approval at all, so `risky: true` may not reach Clara.

## Installer snippet

Make your installer install Clara when it is missing or older than the version you need. In an
electron-builder app's `build/installer.nsh`:

```nsis
!include "clara-install.nsh"

!macro customInstall
    File "/oname=$PLUGINSDIR\Clara Setup.exe" "path\to\Clara Setup 0.1.0.exe"
    !insertmacro ClaraEnsureInstalled "0.1.0" "$PLUGINSDIR\Clara Setup.exe"
!macroend
```

(`clara-install.nsh` lives in `build/clara/` of this repo; add that folder to your NSIS include path.)

- Compares `HKCU\Software\2DLogic\Clara\Version` numerically; equal or newer: nothing runs.
- Clara's setup is per-user and silent (`/S`), asks no UAC, and only installs Git, `claude` or `codex` when
  missing. It never upgrades, downgrades or removes the customer's own.
- It fails soft: if the setup fails, your installer continues and `AttachClara` reports `not-installed`.
- While Clara is running for that user, the setup is skipped; Clara's self-updater delivers it later. Clara
  updates itself from `https://2dlogic.com/clara/` (off when `CLARA_DATA_DIR` or `CLARA_NO_UPDATE` is set).
- Run it from a per-user installer when possible: Clara installs into the profile of the user the installer
  runs as.

## The customer signs in themselves

Clara never signs anyone in and never sees credentials. The customer must have `claude` or `codex` signed in
(they run it once in a terminal and follow its prompt). If not, Clara says so and offers Retry once they
have. The installer installs the CLIs but does not sign them in. Clara is unsigned for now, so Windows
SmartScreen or an antivirus may warn on first run.

## Environment (tests and development)

| Variable | Effect |
|---|---|
| `CLARA_PIPE_SUFFIX` | Use a separate attach pipe, so a test never meets the user's Clara. |
| `CLARA_DATA_DIR` | Clara's data folder instead of `%APPDATA%\Clara`. |

See `examples/clara-demo-host/README.md` for a complete working host.
